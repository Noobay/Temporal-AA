var structtinyShaders_1_1shader__t =
[
    [ "shader_t", "df/da3/structtinyShaders_1_1shader__t.html#a1ab093e71e008f06b655a756a217302e", null ],
    [ "shader_t", "df/da3/structtinyShaders_1_1shader__t.html#a06b216f316f66cd30a8481b0a95da672", null ],
    [ "shader_t", "df/da3/structtinyShaders_1_1shader__t.html#aeb6c6428ccfba836395a25fadea9dc29", null ],
    [ "~shader_t", "df/da3/structtinyShaders_1_1shader__t.html#aab4c43f0c11ff12799a9355ccf67ccbe", null ],
    [ "Compile", "df/da3/structtinyShaders_1_1shader__t.html#ae5a301119adca445588a0eaf04d0e09b", null ],
    [ "Shutdown", "df/da3/structtinyShaders_1_1shader__t.html#a00de3b1c01eae67bd0a2b14992da605c", null ],
    [ "filePath", "df/da3/structtinyShaders_1_1shader__t.html#a625997f1a6cbb5042297c15f3d6a8238", null ],
    [ "handle", "df/da3/structtinyShaders_1_1shader__t.html#a6106fae3debd189fad2b7afd834d31d9", null ],
    [ "iD", "df/da3/structtinyShaders_1_1shader__t.html#a842fcdad1ed558067b6c5fba96e74515", null ],
    [ "isCompiled", "df/da3/structtinyShaders_1_1shader__t.html#aed187512ba37beb31de11a53d10f9f97", null ],
    [ "name", "df/da3/structtinyShaders_1_1shader__t.html#ae1c93854e9e3eafc3f38a0d3a289f80a", null ],
    [ "type", "df/da3/structtinyShaders_1_1shader__t.html#adf133a70c566766d0548493d6f9a0eaf", null ]
];