var TinyShaders_8h =
[
    [ "tinyShaders", "db/d87/classtinyShaders.html", "db/d87/classtinyShaders" ],
    [ "shader_t", "df/da3/structtinyShaders_1_1shader__t.html", "df/da3/structtinyShaders_1_1shader__t" ],
    [ "shaderProgram_t", "dd/d54/structtinyShaders_1_1shaderProgram__t.html", "dd/d54/structtinyShaders_1_1shaderProgram__t" ],
    [ "TINYSHADERS_ERROR_FAILED_SHADER_LOAD", "d2/dcf/TinyShaders_8h.html#a2b27292f8638d945156bc8a94ccdd33b", null ],
    [ "TINYSHADERS_ERROR_FAILED_SHADER_PROGRAM_LINK", "d2/dcf/TinyShaders_8h.html#a9bdd3c875c53f6b8bd9a79d8cfdaa49e", null ],
    [ "TINYSHADERS_ERROR_INVALID_FILE_PATH", "d2/dcf/TinyShaders_8h.html#af35b62de7728b65f38c171b0c57a2c75", null ],
    [ "TINYSHADERS_ERROR_INVALID_SHADER_INDEX", "d2/dcf/TinyShaders_8h.html#aa7f98d5495edcc6b2721b6c9c79f8650", null ],
    [ "TINYSHADERS_ERROR_INVALID_SHADER_NAME", "d2/dcf/TinyShaders_8h.html#ad919837a476152731fae2b47f7ca2f1b", null ],
    [ "TINYSHADERS_ERROR_INVALID_SHADER_PROGRAM_INDEX", "d2/dcf/TinyShaders_8h.html#a6d59a56aeddcd83597e0225afe904907", null ],
    [ "TINYSHADERS_ERROR_INVALID_SHADER_PROGRAM_NAME", "d2/dcf/TinyShaders_8h.html#a77bbba35d70f607fc99cbd30edefbe5a", null ],
    [ "TINYSHADERS_ERROR_INVALID_SHADER_TYPE", "d2/dcf/TinyShaders_8h.html#ae9747379790ec8fdc43184f457ab9535", null ],
    [ "TINYSHADERS_ERROR_INVALID_SOURCE_FILE", "d2/dcf/TinyShaders_8h.html#a305c8c2b4461d07b14a7af24fd0f3ba0", null ],
    [ "TINYSHADERS_ERROR_INVALID_STRING", "d2/dcf/TinyShaders_8h.html#a0513b4232bb63a95938e1e75f73288fd", null ],
    [ "TINYSHADERS_ERROR_NOT_INITIALIZED", "d2/dcf/TinyShaders_8h.html#a25008e10494efe8f6d0217b2286d9cf8", null ],
    [ "TINYSHADERS_ERROR_SHADER_ALREADY_EXISTS", "d2/dcf/TinyShaders_8h.html#afb64834e4aa9526944464e403dbe37b0", null ],
    [ "TINYSHADERS_ERROR_SHADER_NOT_FOUND", "d2/dcf/TinyShaders_8h.html#a988279f4659dea3e226594ce303b8b1f", null ],
    [ "TINYSHADERS_ERROR_SHADER_PROGRAM_ALREADY_EXISTS", "d2/dcf/TinyShaders_8h.html#a87ce026f97d52e4749894e01f17af2fb", null ],
    [ "TINYSHADERS_ERROR_SHADER_PROGRAM_NOT_FOUND", "d2/dcf/TinyShaders_8h.html#a8baf6b94b3891330fdc3cbd8c105cfd2", null ],
    [ "parseBlocks_t", "d2/dcf/TinyShaders_8h.html#a0cf13541a9bd99c76255223275650ef6", null ],
    [ "TinyShaders_PrintErrorMessage", "d2/dcf/TinyShaders_8h.html#abd9fdf3fbddda9dc210e1d046d49bcf0", null ]
];